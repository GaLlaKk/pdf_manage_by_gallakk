﻿# ============================================================
# Fusion de PDF - GaLlaKk
# Application de fusion de fichiers PDF via interface Tkinter
# ============================================================

# Import des bibliothèques nécessaires
import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from tkinterdnd2 import DND_FILES, TkinterDnD

from merge_pdf_service import merge_pdfs


# Classe principale de l'application Tkinter
class MergePdfApp:
    def __init__(self, root):
        # Configuration de la fenêtre principale
        self.root = root
        self.root.title("Fusion de PDF")
        self.root.geometry("700x430")
        self.root.minsize(620, 360)

        # Liste des fichiers PDF sélectionnés et index courant pour les boutons Monter/Descendre
        self.selected_files = []
        self.current_index = 0

        # Titre de l'application
        tk.Label(
            root,
            text="Sélectionnez les fichiers PDF à fusionner :",
            font=("Segoe UI", 11, "bold"),
            anchor="w",
            padx=15,
            pady=10,
        ).pack(fill="x")

        # Signature de l'application
        tk.Label(
            root,
            text="GaLlaKk",
            font=("Segoe UI", 8),
            fg="#666666",
            anchor="e",
            padx=15,
            pady=5,
        ).pack(fill="x")

        # Zone des actions principales : ouvrir des PDF, ajouter un dossier, retirer et réordonner
        frame_actions = tk.Frame(root, padx=15, pady=5)
        frame_actions.pack(fill="x")

        self.open_button = tk.Button(frame_actions, text="Ouvrir PDF", command=self.select_files, width=18, state=tk.NORMAL)
        self.open_button.pack(side="left")

        self.folder_button = tk.Button(frame_actions, text="Ajouter un dossier", command=self.select_folder, width=18, state=tk.NORMAL)
        self.folder_button.pack(side="left", padx=10)

        self.remove_button = tk.Button(frame_actions, text="Retirer la sélection", command=self.remove_selected, width=18, state=tk.NORMAL)
        self.remove_button.pack(side="left")

        self.up_button = tk.Button(frame_actions, text="Monter", command=self.move_up, width=10, state=tk.DISABLED)
        self.up_button.pack(side="left", padx=(10, 0))

        self.down_button = tk.Button(frame_actions, text="Descendre", command=self.move_down, width=10, state=tk.DISABLED)
        self.down_button.pack(side="left")

        # Liste des fichiers sélectionnés pour visualiser l'ordre avant fusion
        self.file_listbox = tk.Listbox(root, selectmode=tk.MULTIPLE, height=14, font=("Segoe UI", 10))
        self.file_listbox.pack(fill="both", expand=True, padx=15, pady=10)
        # Palette de drag & drop compatible Windows via tkinterdnd2
        self.file_listbox.config(bg="#f7f7f7")
        self.file_listbox.drop_target_register(DND_FILES)
        self.file_listbox.dnd_bind('<<Drop>>', self.on_drop)
        self.file_listbox.bind("<Button-1>", self.clear_placeholder)
        self.file_listbox.bind("<ButtonRelease-1>", self.on_listbox_select)
        self.file_listbox.bind("<<ListboxSelect>>", self.on_listbox_select)

        # Zone de configuration du fichier de sortie
        output_frame = tk.Frame(root, padx=15, pady=5)
        output_frame.pack(fill="x")

        tk.Label(output_frame, text="Fichier de sortie :", anchor="w", width=16).pack(side="left")
        self.output_var = tk.StringVar(value="")
        self.output_entry = tk.Entry(output_frame, textvariable=self.output_var, width=60)
        self.output_entry.pack(side="left", fill="x", expand=True, padx=10)
        ttk.Button(output_frame, text="Choisir", command=self.choose_output_file).pack(side="left")

        # Bouton d'action principal pour lancer la fusion
        buttons_frame = tk.Frame(root, padx=15, pady=10)
        buttons_frame.pack(fill="x")

        self.merge_button = tk.Button(buttons_frame, text="Fusionner", command=self.merge_selected_files, width=18, state=tk.DISABLED)
        self.merge_button.pack(side="right")

        self.refresh_list()

    # Ouvre la boîte de dialogue standard pour sélectionner un ou plusieurs fichiers PDF
    def select_files(self):
        files = filedialog.askopenfilenames(
            title="Sélectionner les fichiers PDF",
            filetypes=[("Tous les fichiers", "*.*"), ("Fichiers PDF", "*.pdf")],
        )
        if not files:
            return

        pdf_files = []
        for file_path in files:
            if file_path.lower().endswith(".pdf"):
                pdf_files.append(file_path)

        if not pdf_files:
            messagebox.showwarning("Aucun PDF", "Veuillez sélectionner au moins un fichier PDF.")
            return

        for file_path in pdf_files:
            if file_path not in self.selected_files:
                self.selected_files.append(file_path)

        self.refresh_list()
        self.file_listbox.selection_clear(0, tk.END)

    # Ajoute tous les PDF présents dans un dossier donné
    def select_folder(self):
        folder_path = filedialog.askdirectory(title="Sélectionner un dossier contenant des PDF")
        if not folder_path:
            return

        pdf_files = []
        for file_name in sorted(os.listdir(folder_path)):
            full_path = os.path.join(folder_path, file_name)
            if os.path.isfile(full_path) and full_path.lower().endswith(".pdf"):
                pdf_files.append(full_path)

        for file_path in pdf_files:
            if file_path not in self.selected_files:
                self.selected_files.append(file_path)

        self.refresh_list()
        self.file_listbox.selection_clear(0, tk.END)

    # Supprime le texte d'invite quand l'utilisateur clique dans la zone de liste
    def clear_placeholder(self, event=None):
        if self.selected_files:
            return
        self.file_listbox.delete(0, tk.END)

    # Met à jour l'index courant et l'état des boutons selon la sélection dans la liste
    def on_listbox_select(self, event=None):
        selected_indexes = self.file_listbox.curselection()
        if selected_indexes:
            self.current_index = selected_indexes[0]
        elif self.selected_files:
            self.current_index = 0
        self.refresh_buttons()

    # Ajoute des fichiers glissés depuis l'explorateur Windows
    def on_drop(self, event):
        file_paths = []
        try:
            file_paths = self.file_listbox.tk.splitlist(event.data)
        except Exception:
            file_paths = []

        pdf_files = []
        for file_path in file_paths:
            if file_path.lower().endswith(".pdf"):
                pdf_files.append(file_path)

        if not pdf_files:
            messagebox.showwarning("Aucun PDF", "Glissez uniquement des fichiers PDF.")
            return ""

        for file_path in pdf_files:
            if file_path not in self.selected_files:
                self.selected_files.append(file_path)

        self.refresh_list()
        self.file_listbox.selection_clear(0, tk.END)
        return ""

    # Monte le fichier sélectionné dans la liste pour changer l'ordre de fusion
    def move_up(self):
        if not self.selected_files or self.current_index <= 0:
            return
        index = self.current_index
        self.selected_files[index], self.selected_files[index - 1] = self.selected_files[index - 1], self.selected_files[index]
        self.current_index = index - 1
        self.refresh_list()
        self.file_listbox.selection_set(self.current_index)
        self.refresh_buttons()

    # Descend le fichier sélectionné dans la liste pour changer l'ordre de fusion
    def move_down(self):
        if not self.selected_files or self.current_index >= len(self.selected_files) - 1:
            return
        index = self.current_index
        self.selected_files[index], self.selected_files[index + 1] = self.selected_files[index + 1], self.selected_files[index]
        self.current_index = index + 1
        self.refresh_list()
        self.file_listbox.selection_set(self.current_index)
        self.refresh_buttons()

    # Retire les fichiers sélectionnés dans la liste
    def remove_selected(self):
        selected_indexes = list(self.file_listbox.curselection())
        if not selected_indexes:
            return
        for index in sorted(selected_indexes, reverse=True):
            del self.selected_files[index]
        self.refresh_list()

    # Active ou désactive les boutons selon l’état courant de l’application
    def refresh_buttons(self):
        has_files = bool(self.selected_files)
        self.merge_button.config(state=tk.NORMAL if has_files else tk.DISABLED)
        self.remove_button.config(state=tk.NORMAL if has_files else tk.DISABLED)

        if not has_files:
            self.up_button.config(state=tk.DISABLED)
            self.down_button.config(state=tk.DISABLED)
            return

        index = self.current_index if self.current_index < len(self.selected_files) else len(self.selected_files) - 1
        self.up_button.config(state=tk.NORMAL if index > 0 and len(self.selected_files) > 1 else tk.DISABLED)
        self.down_button.config(state=tk.NORMAL if index < len(self.selected_files) - 1 and len(self.selected_files) > 1 else tk.DISABLED)

    # Recharge la liste à partir des fichiers sélectionnés et met à jour l’état des boutons
    def refresh_list(self):
        self.file_listbox.delete(0, tk.END)
        if not self.selected_files:
            self.file_listbox.insert(tk.END, "Glissez ici vos fichiers PDF")
            self.file_listbox.config(bg="#f7f7f7")
            self.file_listbox.selection_clear(0, tk.END)
            self.current_index = 0
        else:
            for file_path in self.selected_files:
                self.file_listbox.insert(tk.END, os.path.basename(file_path))
            self.file_listbox.config(bg="white")
            if self.current_index >= len(self.selected_files):
                self.current_index = len(self.selected_files) - 1
            self.file_listbox.selection_set(self.current_index)
        self.refresh_buttons()

    # Demande le chemin du fichier PDF final à générer
    def choose_output_file(self):
        default_name = "fusion.pdf"
        if self.selected_files:
            default_name = os.path.splitext(os.path.basename(self.selected_files[0]))[0] + "_fusion.pdf"

        output_path = filedialog.asksaveasfilename(
            title="Enregistrer le PDF fusionné",
            defaultextension=".pdf",
            filetypes=[("Fichiers PDF", "*.pdf")],
            initialfile=default_name,
        )

        if output_path:
            self.output_var.set(output_path)

    # Lance la fusion des PDF en fonction de la liste et du chemin de sortie
    def merge_selected_files(self):
        if not self.selected_files:
            messagebox.showwarning("Aucune sélection", "Veuillez sélectionner au moins un fichier PDF.")
            return

        output_path = self.output_var.get().strip()
        if not output_path:
            output_path = os.path.join(
                os.path.dirname(self.selected_files[0]),
                "fusion.pdf",
            )

        if not output_path.lower().endswith(".pdf"):
            output_path += ".pdf"

        try:
            merge_pdfs(self.selected_files, output_path)
            messagebox.showinfo(
                "Fusion réussie",
                f"Le fichier PDF a bien été créé :\n{output_path}",
            )
        except Exception as exc:
            messagebox.showerror("Erreur", f"La fusion a échoué :\n{exc}")


if __name__ == "__main__":
    root = TkinterDnD.Tk()
    app = MergePdfApp(root)
    root.mainloop()
