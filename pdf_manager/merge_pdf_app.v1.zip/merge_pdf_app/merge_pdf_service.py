# ============================================================
# Service métier PDF - GaLlaKk
# Logique de fusion et validation des fichiers PDF
# ============================================================

import os

from pypdf import PdfWriter


def merge_pdfs(pdf_files, output_path):
    """Fusionne plusieurs fichiers PDF dans l'ordre de sélection."""
    if not pdf_files:
        raise ValueError("Aucun fichier PDF sélectionné.")

    output_path = os.path.abspath(output_path)
    output_dir = os.path.dirname(output_path) or os.getcwd()
    if not os.path.isdir(output_dir):
        os.makedirs(output_dir, exist_ok=True)

    writer = PdfWriter()
    try:
        for pdf_file in pdf_files:
            if not os.path.isfile(pdf_file):
                raise FileNotFoundError(f"Fichier introuvable : {pdf_file}")
            writer.append(pdf_file)

        writer.write(output_path)
    finally:
        writer.close()


def is_pdf_file(path):
    """Retourne True si le chemin correspond à un fichier PDF."""
    return isinstance(path, str) and path.lower().endswith(".pdf") and os.path.isfile(path)
